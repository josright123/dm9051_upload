#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif


static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x92997ed8, "_printk" },
	{ 0x37a0cba, "kfree" },
	{ 0x1546387d, "skb_pull" },
	{ 0xa5b6ed22, "skb_trim" },
	{ 0xa9c64948, "_dev_err" },
	{ 0xc6ef19cd, "usbnet_write_cmd" },
	{ 0x86cb2ccb, "mii_link_ok" },
	{ 0x83d38682, "usbnet_get_drvinfo" },
	{ 0x4c36dc53, "generic_mii_ioctl" },
	{ 0xd484a36b, "usb_free_urb" },
	{ 0x741e55dd, "usb_alloc_urb" },
	{ 0x63ac9375, "kmalloc_caches" },
	{ 0x45f84c31, "kmalloc_trace" },
	{ 0x596f57a8, "usb_submit_urb" },
	{ 0x8da6585d, "__stack_chk_fail" },
	{ 0x981978dc, "dev_addr_mod" },
	{ 0x69dd3b5b, "crc32_le" },
	{ 0x829237ab, "usb_register_driver" },
	{ 0x61cd8d96, "usb_deregister" },
	{ 0x4e21ec53, "netif_carrier_on" },
	{ 0xe26b8314, "usbnet_defer_kevent" },
	{ 0xf837559e, "netif_carrier_off" },
	{ 0x8fe60082, "usbnet_read_cmd" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0xe0bf49fe, "usb_control_msg" },
	{ 0xdcb764ad, "memset" },
	{ 0x64b2a32b, "mii_check_media" },
	{ 0x81ace387, "mii_ethtool_gset" },
	{ 0x83cb1122, "usbnet_get_endpoints" },
	{ 0x69ca122a, "mii_nway_restart" },
	{ 0x4a3ae909, "skb_copy_expand" },
	{ 0x53e63b47, "__dev_kfree_skb_any" },
	{ 0x5b737922, "usbnet_open" },
	{ 0xab35d039, "usbnet_stop" },
	{ 0x6c2ab59d, "usbnet_start_xmit" },
	{ 0x63fa0340, "eth_validate_addr" },
	{ 0xa914eec8, "usbnet_change_mtu" },
	{ 0xcb989f20, "usbnet_tx_timeout" },
	{ 0xd9e53765, "usbnet_probe" },
	{ 0x97a47af1, "usbnet_disconnect" },
	{ 0x5c4c4001, "usbnet_suspend" },
	{ 0xdbdfb74e, "usbnet_resume" },
	{ 0x2f665059, "usbnet_get_msglevel" },
	{ 0x85150009, "usbnet_set_msglevel" },
	{ 0xdd7bd2f3, "usbnet_nway_reset" },
	{ 0x607eeffd, "usbnet_get_link_ksettings_mii" },
	{ 0xf4d43af, "usbnet_set_link_ksettings_mii" },
	{ 0xf7038a43, "module_layout" },
};

MODULE_INFO(depends, "");

MODULE_ALIAS("usb:v0A46p9620d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0A46p9621d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0A46p9622d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0A46p0269d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0A46p1269d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0A46p0268d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0A46p1268d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0A46p0267d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0A46p1267d*dc*dsc*dp*ic*isc*ip*in*");

MODULE_INFO(srcversion, "F728CE281D8E0F702E4A770");
